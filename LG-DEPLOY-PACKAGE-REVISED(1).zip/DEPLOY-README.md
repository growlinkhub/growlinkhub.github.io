# LG GitHub Pages package — owner approval UI build

## Included files
- `index.html` — main app
- `test.html` — test copy of the main app
- `admin.html` — separate owner-only review panel with tabs for new users, recharge, LG 1 approvals, withdrawals and all users
- `firestore.rules` — rules template with owner UID placeholder and registrationStatus create-field allowance
- `backup-v1.html` — preserved backup
- `BUILD-CHECKS.json` — build audit notes

## Owner password and UID
- No password is hard-coded in HTML, JavaScript, README, or ZIP.
- The Admin Panel signs in through the existing Firebase Authentication account (mobile number + `@reelcoin.app` email convention + the private Firebase password).
- Set your own Firebase Auth UID in `admin.html` by replacing `ADMIN_UID_HERE`.
- Do not send your password to anyone or put it in GitHub. Keep it only in your private password manager / secure place.

## Owner panel workflow
1. Open `/admin.html` and sign in using your own Firebase account.
2. `New users` lists pending registrations with phone/invitation details. Approve lets the new account enter; Reject keeps it blocked at login. New registrations start as Pending. Existing accounts without a registrationStatus field are preserved and are not blocked.
3. `Recharge` lists pending UPI requests. Verify the money actually arrived in your bank/UPI account before `Approve & credit wallet`.
4. `LG 1 approvals` lists paid LG 1 requests. Approve to set the user's LG 1 approval flag; reject refunds the requested coins.
5. `Withdrawals` lists bank details and amount. Approve starts the displayed 48-hour manual processing window. After you actually transfer money, press `Mark paid`. Reject refunds the coins.
6. `All users` shows user-level summary/history counts.

## Existing app behavior retained
- Existing Firebase login/signup/invitation block and CSP are preserved.
- Existing UPI ID/payee are preserved.
- Existing video/question task UI and reward logic are preserved; no external video feed is required by this build.
- Signed-in user screens listen for owner approval/state updates so an approved LG 1 can appear without relying only on a manual page reload.
- Financial Fund Buy uses the Main Wallet balance.
- LG 1 remains locked until owner approval; LG 2–LG 5 remain locked.
- No password is shown in the app or stored in source.

## Important technical/security status
This is an owner approval **UI workflow**, not a secure real-money wallet implementation. The existing app stores wallet balance, task rewards, purchases, recharge requests and withdrawal records in the user's `state` JSON. The current user update rule allows the account owner to modify that state, so a technically skilled user can tamper with balances/statuses. The Admin Panel also writes that JSON state. Do not accept deposits or promise cash payouts until you implement trusted server-side ledger/validation and restrictive Firestore rules. Publishing the rules file as-is does not solve this problem.

The panel does not verify UPI automatically and does not transfer money to bank accounts. Those are manual owner operations. Do not mark a withdrawal paid until the bank transfer is complete.

## Upload order
1. First configure your own UID in `admin.html` (and arrange the Firebase rules/security separately).
2. Upload `index.html`, `test.html`, and `admin.html` to the GitHub Pages repository root.
3. Keep `backup-v1.html` as a rollback copy; do not rename it to `index.html`.
4. Test the site and `/admin.html` with a test account before switching real users.
